<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_user extends CI_model {



}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
